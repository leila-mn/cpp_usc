#ifndef PRODUCT_H
#define PRODUCT_H
#include <vector>
#include <algorithm>
#include <string>
#include <cctype>
#include<cmath>
#include <bits/stdc++.h>
#include <iostream>
#include <stdio.h>
#include <vector>
#include <set>
#include <stdio.h>
#include <stdlib.h>
#include <string>
using namespace std;

/*
product no, product name, price, qty, tax, discount.
*/
//sort in binary file
struct product_specification{
    string product_no;
    string product_name;
    string price;
    string qty;
    string date;
};

class product{
public:
    product();
    virtual ~product();
    bool create_new_product();
    bool modify_product();
    void delete_product();/////?????
    void display_all_product();
    void create_bill();
private:
    vector<product_specification *> store;
};

#endif // PRODUCT_H
