#include "product.h"

product::product(){
    store =vector<product_specification *>(14);
    
    string product_namee [14] {"Asparagus", "Gravy", "Milk", " Parmesan", "Cereal", "Lunchmeat", "Catfish", "Ginger", "Popsicles", "Napkins", "Arsenic", "Batteries", "Cosmetics", "Yeast"};
    string product_noo   [14] {"1000", "1001", "1002", "1003", "1004", "1005", "1006", "1007", "1008", "1009", "1010", "1011", "1012", "1013"};
    string product_price [14] {"10$", "15$", "54$", "6$", "45$", "7$", "22$", "32$", "15$", "12$", "7$", "77$", "9$", "15$"};
    string product_qty   [14] {"20", "20", "20", "20", "12", "12", "12", "7", "7", "7", "7", "8", "8", "8"};
    string product_date  [14] {"2014-01-01", "2014-01-02", "2014-01-03", "2014-01-04", "2014-01-05", "2014-01-06", "2014-01-07", "2014-01-08", "2014-01-09", "2014-01-10", "2014-01-11", "2014-01-12", "2014-01-13","2014-01-14"};
    int x = store.size();
    for (int i = 0; i < x; i++){
        store[i] = new product_specification();
        store[i]->product_name = product_namee[i];
        store[i]->product_no = product_noo[i];
        store[i]->price = product_price[i];
        store[i]->qty = product_qty[i];
        store[i]->date = product_date[i];
    }
}

product::~product()
{
    //dtor
}

bool product::create_new_product(){
    product_specification *new_product;
    new_product = new product_specification();
    cout<<"\n\n\tPlease Enter The Product No. of The Product (start by ID=1000 )";
    cin>>new_product->product_no;
    if(new_product->product_no == "-1"){
        cout<<"\tYou can't add ID -1 \n \tplease try again\n";
        create_new_product();
    }
    cout<<"\n\tPlease Enter The Name of The Product ";
    cin>>new_product->product_name;
    cout<<"\n\tPlease Enter The Price of The Product ";
    cin>>new_product->price;
    cout<<"\n\tPlease Enter The quantity (%) ";
    cin>>new_product->qty;
    cout<<"\n\tPlease Enter The Date(dd-mm-yy) ";
    store.push_back(new_product);
    return 1;
}

bool product::modify_product(){
    string n;
    cout<<"\n                Please Enter The Product No. of The Product (start by ID=1000 ) ";
    cin>>n;
    int x = store.size();
    for(int i=0;i<x;i++){
        if(store[i]->product_no == n){
            cout<<"\n\n \tThe Name of The Product ";   
            cin>>store[i]->product_name;
            cout<<"\n \tThe Price of The Product ";
            cin>>store[i]->price;
            cout<<"\n \tThe quantity (%) ";
            cin>>store[i]->qty;
            cout<<"\n \tThe Date ";
            cin>>store[i] ->date;
            return 1;
        }
    }
    cout<<"not found "<<endl;return false;
}

void product::display_all_product(){
    int x = store.size();
    for(int i=0;i<x;i++){
            cout<<"\n The Product No. of The Product ";
            cout<<store[i]->product_no;
            cout<<"\n The Name of The Product ";
            cout<<store[i]->product_name;
            cout<<"\n The Price of The Product ";
            cout<<store[i]->price;
            cout<<"\n The quantity (%) ";
            cout<<store[i]->qty;
            cout<<"\n The Date "<<endl;
    }
    cout<<"\n";
}

void product::delete_product(){
    string n;
    cout<<"\n                Please Enter The Product No. of The Product (start by ID=1000 ) ";
    cin>>n;
    int x = store.size();
    for(int i=0;i<x;i++){
        if(store[i]->product_no == n){
            for (auto it = store.begin(); it != store.end();){
                if(store[i]->product_no == n){
                    it = store.erase(it);
                } else {++it;}
            }
        }
    }
}