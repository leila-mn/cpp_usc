#include "product.h"


int main(){
    product obj;
    
    while (true){
        cout<<"\n\t          Super Market Billing\n\t          ===============================\n";
        cout<<"\t1.Bill Report\n\t2.Add/Remove/Edit Item\n\t3.Show Item Details\n\t4.Exit\n\n\n";
        cout<<"\tPlease Enter Required Option:\n";
        char x;
        cin>>x;
        system("cLs");
        
        if(x=='1'){
            cout<<"\n\t          Bill Report\n\t          ===============================\n";
            cout<<"\n\t Bill is empty\n";
        }

        else if(x=='2'){
            cout<<"\n\t          Bill Editor\n\t          ===============================\n";
            cout<<"\t1.Add Item Details\n\t2.Edit Item Details\n\t3.Delete Item Details\n\t4.Back to Main Menu 1\n\n\n";
            char r;
            cin>>r;
            system("cLs");
            if(r=='1'){obj.create_new_product();}
            else if(r=='2'){obj.modify_product();}
            else if(r=='3'){obj.delete_product();}
            else if(r=='4'){}
            else{
                cout<<"   EROOR!!!\n";
            }
        }
        else if(x=='3'){
            cout<<"\n\t          Show Item Details\n\t          ===============================\n";
            obj.display_all_product();
        }
        else if(x=='4'){ cout<<"\n\t\t\t thank you for used our app"<<endl;return 0;}

    }
    
    

    return 0;
}