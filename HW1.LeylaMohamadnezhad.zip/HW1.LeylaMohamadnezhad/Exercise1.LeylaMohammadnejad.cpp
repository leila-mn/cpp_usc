#include<iostream>
#include<string>

using namespace std;

class Person{
	public:
	string name,family;
	void printName();
};
void Person::printName(){
	cout<<"the whole name is:"+ this -> name+ " " + family;
}
class student: public Person
{
	public:
		string name,family;
};
class Teacher:public Person 
{
	public:
		string name,family;
};
int main(){
	Person personOne;
	personOne.name = "Ali";
	personOne.family= "Alizade";
	personOne.printName();
	
	return 0;
}
