#ifndef JSONOBJECT_H
#define JSONOBJECT_H


#include "jsonContainer.h"
#include "jsonArray.h"
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
using namespace std;
class jsonObject:public jsonContainer{
private:
    string key;
    static int counter;
    vector<pair<string,string>> pairsOfStrings;
    vector<pair<string,int>> pairsOfIntegers;
    static std::vector<jsonObject*> allObjects;
public:
    jsonObject();
    ~jsonObject(){};
    static vector<string>lines2Print;
    static void addStringToObject(const int parentId,const string key,const string value);
    static void addIntegerToObject(const int parentId,const string key,const int value);
    static int addContainerToObject(int parentId,string key,string type);
    static void prints(int id);
    static void print(int id);
};
#endif