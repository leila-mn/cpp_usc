# include "jsonContainer.h"
# include "jsonArray.h"
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

int jsonArray::counter = 0;
std::vector<jsonArray*> jsonArray::allArrays{};
void jsonArray::addStringToArray(const int parentId,const string value){
    for (int i=0;i<allArrays.size();i++){
        if(parentId == allArrays[i]->ID){
            allArrays[i]->stringMembers.push_back(value);
            return;
        }
    }
    throw std::runtime_error("Invalid id");
}
void jsonArray::addIntegerToArray(const int parentId,const int value){
    for (int i=0;i<allArrays.size();i++){
        if(parentId == allArrays[i]->ID){
            allArrays[i]->intMembers.push_back(value);
            return;
        }
    }
    throw std::runtime_error("Invalid id");
}
int jsonArray::addContainerToArray(const int parentId,const string type){
    if (type == "array"){
        for (int i=0;i<allArrays.size();i++){
            if(parentId == allArrays[i]->ID){
                jsonArray* newArr = new jsonArray;
                allArrays[i]->arrayMembers.push_back(newArr);
                return newArr->getID();
            }
        }
        throw std::runtime_error("Invalid id");
    }
    else if(type == "object"){
        for (int i=0;i<allArrays.size();i++){
            if(parentId == allArrays[i]->ID){
                jsonObject* newObj = new jsonObject;
                allArrays[i]->objctMembers.push_back(newObj);
                return newObj->getID();
            }
        }
        throw std::runtime_error("Invalid id");
    }
    else{
        throw std::runtime_error("Undefined type");
    }
}
void jsonArray::prints(int id){
    for (int i=0;i<allArrays.size();i++){
        if(id == allArrays[i]->ID){
            jsonObject::lines2Print.push_back(string("[\n"));
            for ( vector<string>::const_iterator it = allArrays[i]->stringMembers.begin() ; it != allArrays[i]->stringMembers.end(); it++){
                jsonObject::lines2Print.push_back(string("\"")+*it+string("\"")+string(",\n"));
            }
            for ( vector<int>::const_iterator it = allArrays[i]->intMembers.begin() ; it != allArrays[i]->intMembers.end(); it++){
                jsonObject::lines2Print.push_back(std::to_string(*it)+string(",\n"));
            }
            for (int j=0;j<allArrays[i]->arrayMembers.size();j++){
                jsonArray::prints(allArrays[i]->arrayMembers[j]->getID());
            }
            for (int j=0;j<allArrays[i]->objctMembers.size();j++){
                jsonObject::prints(allArrays[i]->objctMembers[j]->getID());
            }
            jsonObject::lines2Print.push_back(string("],\n"));
            break;
        }
    }
}
void jsonArray::print(int id){
    jsonArray::prints(id);
    int tabs=0;
    for (int i=0;i<jsonObject::lines2Print.size();i++){
        if(jsonObject::lines2Print[i]=="{\n" || jsonObject::lines2Print[i]=="[\n"){
            for (int t=0;t<tabs;t++){
                cout<<"    ";
            }
            cout<<jsonObject::lines2Print[i];
            tabs++;
        }
        else if(jsonObject::lines2Print[i]=="},\n" || jsonObject::lines2Print[i]=="],\n"){
            tabs--;
            for (int t=0;t<tabs;t++){
                cout<<"    ";
            }
            cout<<jsonObject::lines2Print[i];
        }
        else{
            for (int t=0;t<tabs;t++){
                cout<<"    ";
            }
            cout<<jsonObject::lines2Print[i];
        }
    }
}