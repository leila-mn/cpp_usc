#include"jsonArray.h"
#include"jsonObject.h"
int main(){
    jsonObject o1;
    jsonArray array;
    jsonArray::addStringToArray(0,"adf");
    jsonArray::addIntegerToArray(0,100);
    int a = jsonObject::addContainerToObject(0,"thisArray","array");
    int b = jsonArray::addContainerToArray(0,"object");
    jsonObject::addStringToObject(b,"key","hello");
    jsonObject::addIntegerToObject(b,"asdfKey",666);
    int c = jsonObject::addContainerToObject(b,"ArrayKey","array");
    int d = jsonArray::addContainerToArray(c,"object");
    jsonObject::addStringToObject(d,"range_mashin","qermez");
    jsonObject::addStringToObject(d,"mahale_sokoonat","tehran");

    jsonArray::addStringToArray(a,"asfsdf");
    jsonArray::print(0);
    return 0;
}
