#ifndef JSONCONTAINER_H
#define JSONCONTAINER_H

#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <memory>

using namespace std;

class jsonContainer{
protected:
    string key;
    int ID;
    vector<jsonContainer*> objctMembers;
    vector<jsonContainer*> arrayMembers;
public:
    int getID() { return ID;};
    string getKey(){return key;}
    jsonContainer(){};
    virtual ~jsonContainer(){};
};
#endif