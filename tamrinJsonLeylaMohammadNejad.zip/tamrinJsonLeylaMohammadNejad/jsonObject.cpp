#include "jsonObject.h"
# include "jsonArray.h"
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

int jsonObject::counter = 0;
std::vector<jsonObject*> jsonObject::allObjects{};
std::vector<string> jsonObject::lines2Print{};
jsonObject::jsonObject(){
    ID=counter++;
    jsonObject::allObjects.push_back(this);
}
void jsonObject::addStringToObject(int parentId, string key,string value){
    for (int i = 0;i<allObjects.size();i++){
        if (allObjects[i]->ID == parentId){
            jsonObject* tempPtr = allObjects[i];
            for ( vector<pair<string,int>>::const_iterator it = tempPtr->pairsOfIntegers.begin() ; it != tempPtr->pairsOfIntegers.end(); it++){
                if(key == it->first){
                    throw std::runtime_error("Duplicate key");
                }
            }
            for ( vector<pair<string,string>>::const_iterator it = tempPtr->pairsOfStrings.begin() ; it != tempPtr->pairsOfStrings.end(); it++){
                if(key == it->first){
                    throw std::runtime_error("Duplicate key");
                }
            }
            for (int j=0;j<tempPtr->arrayMembers.size();j++){
                if(key == tempPtr->arrayMembers[j]->getKey()){
                    throw std::runtime_error("Duplicate key");
                }
            }
            for (int j=0;j<tempPtr->objctMembers.size();j++){
                if(key == tempPtr->objctMembers[j]->getKey()){
                    throw std::runtime_error("Duplicate key");
                }
            }
            tempPtr->pairsOfStrings.push_back({key,value});
        } 
    }
}
void jsonObject::addIntegerToObject(int parentId, string key,int value){
    for (int i = 0;i<allObjects.size();i++){
        if (allObjects[i]->ID == parentId){
            jsonObject* tempPtr = allObjects[i];
            for ( vector<pair<string,int>>::const_iterator it = tempPtr->pairsOfIntegers.begin() ; it != tempPtr->pairsOfIntegers.end(); it++){
                if(key == it->first){
                    throw std::runtime_error("Duplicate key");
                }
            }
            for ( vector<pair<string,string>>::const_iterator it = tempPtr->pairsOfStrings.begin() ; it != tempPtr->pairsOfStrings.end(); it++){
                if(key == it->first){
                    throw std::runtime_error("Duplicate key");
                }
            }
            for (int j=0;j<tempPtr->arrayMembers.size();j++){
                if(key == tempPtr->arrayMembers[j]->getKey()){
                    throw std::runtime_error("Duplicate key");
                }
            }
            for (int j=0;j<tempPtr->objctMembers.size();j++){
                if(key == tempPtr->objctMembers[j]->getKey()){
                    throw std::runtime_error("Duplicate key");
                }
            }
            tempPtr->pairsOfIntegers.push_back({key,value});
        } 
    }
}
int jsonObject::addContainerToObject(int parentId,string key,string type){
    if (type == "array"){
        for (int i = 0;i<allObjects.size();i++){
            if (allObjects[i]->ID == parentId){
                jsonObject* tempPtr = allObjects[i];
                for ( vector<pair<string,int>>::const_iterator it = tempPtr->pairsOfIntegers.begin() ; it != tempPtr->pairsOfIntegers.end(); it++){
                    if(key == it->first){
                        throw std::runtime_error("Duplicate key");
                    }
                }
                for ( vector<pair<string,string>>::const_iterator it = tempPtr->pairsOfStrings.begin() ; it != tempPtr->pairsOfStrings.end(); it++){
                    if(key == it->first){
                        throw std::runtime_error("Duplicate key");
                    }
                }
                for (int j=0;j<tempPtr->arrayMembers.size();j++){
                    if(key == tempPtr->arrayMembers[j]->getKey()){
                        throw std::runtime_error("Duplicate key");
                    }
                }
                for (int j=0;j<tempPtr->objctMembers.size();j++){
                    if(key == tempPtr->objctMembers[j]->getKey()){
                        throw std::runtime_error("Duplicate key");
                    }
                }
                jsonArray* newArr = new jsonArray;
                tempPtr->arrayMembers.push_back(newArr);
                return newArr->getID();
            } 
        }
        throw std::runtime_error("Invalid id");
    }
    else if(type == "object"){
        for (int i = 0;i<allObjects.size();i++){
            if (allObjects[i]->ID == parentId){
                jsonObject* tempPtr = allObjects[i];
                for ( vector<pair<string,int>>::const_iterator it = tempPtr->pairsOfIntegers.begin() ; it != tempPtr->pairsOfIntegers.end(); it++){
                    if(key == it->first){
                        throw std::runtime_error("Duplicate key");
                    }
                }
                for ( vector<pair<string,string>>::const_iterator it = tempPtr->pairsOfStrings.begin() ; it != tempPtr->pairsOfStrings.end(); it++){
                    if(key == it->first){
                        throw std::runtime_error("Duplicate key");
                    }
                }
                for (int j=0;j<tempPtr->arrayMembers.size();j++){
                    if(key == tempPtr->arrayMembers[j]->getKey()){
                        throw std::runtime_error("Duplicate key");
                    }
                }
                for (int j=0;j<tempPtr->objctMembers.size();j++){
                    if(key == tempPtr->objctMembers[j]->getKey()){
                        throw std::runtime_error("Duplicate key");
                    }
                }
                jsonObject* newObj = new jsonObject;
                tempPtr->objctMembers.push_back(newObj);
                return newObj->getID();
            } 
        }
        throw std::runtime_error("Invalid id");
    }
    else{
        throw std::runtime_error("Undefined type");
    }
}
void jsonObject::prints(int id){
    for (int i=0;i<allObjects.size();i++){
        if(id == allObjects[i]->ID){
            jsonObject::lines2Print.push_back(string("{\n"));
            for ( vector<pair<string,string>>::const_iterator it = allObjects[i]->pairsOfStrings.begin() ; it != allObjects[i]->pairsOfStrings.end(); it++){
                jsonObject::lines2Print.push_back(string("\"")+it->first+string("\"")+" : "+string("\"")+it->second+string("\"")+string(",\n"));
            }
            for ( vector<pair<string,int>>::const_iterator it = allObjects[i]->pairsOfIntegers.begin() ; it != allObjects[i]->pairsOfIntegers.end(); it++){
                jsonObject::lines2Print.push_back(string("\"")+it->first+string("\"")+" : "+std::to_string(it->second)+string(",\n"));
            }
            for (int j=0;j<allObjects[i]->arrayMembers.size();j++){
                jsonArray::prints(allObjects[i]->arrayMembers[j]->getID());
            }
            for (int j=0;j<allObjects[i]->objctMembers.size();j++){
                jsonObject::prints(allObjects[i]->objctMembers[j]->getID());
            }
            jsonObject::lines2Print.push_back(string("},\n"));
            break;
        }
    }
}
void jsonObject::print(int id){
    jsonObject::prints(id);
    int tabs=0;
    for (int i=0;i<jsonObject::lines2Print.size();i++){
        if(jsonObject::lines2Print[i]=="{\n" || jsonObject::lines2Print[i]=="[\n"){
            for (int t=0;t<tabs;t++){
                cout<<"    ";
            }
            cout<<jsonObject::lines2Print[i];
            tabs++;
        }
        else if(jsonObject::lines2Print[i]=="},\n" || jsonObject::lines2Print[i]=="],\n"){
            tabs--;
            for (int t=0;t<tabs;t++){
                cout<<"    ";
            }
            cout<<jsonObject::lines2Print[i];
        }
        else{
            for (int t=0;t<tabs;t++){
                cout<<"    ";
            }
            cout<<jsonObject::lines2Print[i];
        }

    }
}