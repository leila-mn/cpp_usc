#ifndef JSONARRAY_H
#define JSONARRAY_H

#include "jsonContainer.h"
#include "jsonObject.h"
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

class jsonArray:public jsonContainer{
private:
    string key;
    static int counter;
    vector<string> stringMembers;
    vector<int> intMembers;
    static std::vector<jsonArray*> allArrays;
public:
    jsonArray(){
        ID = counter++;
        allArrays.push_back(this);
    }
    jsonArray(string k):key(k){ID = counter++;}
    static void addStringToArray(const int parentId,const string value);
    static void addIntegerToArray(const int parentId,const int value);
    static int addContainerToArray(const int parentId,const string type);
    static void prints(int id);
    static void print(int id);
};
#endif
