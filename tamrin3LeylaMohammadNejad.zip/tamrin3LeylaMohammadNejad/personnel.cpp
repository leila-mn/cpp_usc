#include <string>
#include <vector>
#include "personnel.h"
using namespace std;

nurse::nurse(string inputName){
    this->idNumber=-1;      // hanooz vared nashode (-1 mizarim)
    this->nationalNumber=-1;
    this->name = inputName;
}
float nurse::getSalary(){
    return this->salary;
}
long nurse::getId(){
    return this->idNumber;
}
long nurse::getNationalNum(){
    return this->nationalNumber;
}
string nurse::getName(){
    return this->name;
}
void nurse::setSalary(float inputSalary){
    this->salary=inputSalary;
}
void nurse::setidNumber(long inputID){
    this->idNumber=inputID;
}
void nurse::setNationalNum(long inputNN){
    this->nationalNumber=inputNN;
}
void nurse::setName(string inputName){
    this->name=inputName;
}
void doctor::setSpecialty(string inputSpeciality){
    this->specialty=inputSpeciality;
}
string doctor::getSpecialty(){
    return this->specialty;
}
string doctor::getName(){
    return this->name;
}
doctor::doctor(string inputName):nurse(inputName){
    this->name = inputName;
}
