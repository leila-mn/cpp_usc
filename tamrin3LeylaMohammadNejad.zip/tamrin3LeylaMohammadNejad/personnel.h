#ifndef PERSONNEL_H
#define PERSONNEL_H

#include <string>
using namespace std;

class nurse{
private:
    float salary;
    long idNumber;
    long nationalNumber;
    string name;
public:
    nurse(){};
    nurse(string inputName);
    float getSalary();
    long getId();
    long getNationalNum();
    string getName();
    void setSalary(float inputSalary);
    void setidNumber(long inputID);
    void setNationalNum(long inputNN);
    void setName(string inputName);
};
class doctor:public nurse{
private:
    float salary;
    long idNumber;
    long nationalNumber;
    string name;
    string specialty;
public:
    doctor(){};
    doctor(string inputName);
    float getSalary();
    long getId();
    string getName();
    string getSpecialty();
    void setSpecialty(string inputSpeciality);
};
#endif