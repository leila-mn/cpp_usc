#ifndef HOSPITAL_H
#define HOSPITAL_H

#include "personnel.h"
#include <vector>
#include <iostream>

using namespace std;

class hospital{
    string name;
    vector<doctor>doctors;
    vector<nurse>nurses;
public:
    hospital(){
        vector<doctor>doctors{};
        vector<nurse>nurses{};
        this->name="doesn't have a name yet!!!!!!\n";
    };
    string getName(){return this->name;};
    void setName(string inputName){this->name = inputName;}
    vector<doctor> getDoctors(){return this->doctors;};
    void addDoctor(doctor& d1){this->doctors.push_back(d1);};
    vector<nurse> getNurses(){return this->nurses;};
    void addNurse(nurse n1){this->nurses.push_back(n1);};

};
void printEmployees(hospital* h){
    cout<<"hospital name:\t\t"<<h->getName()<<endl;
    cout<<"<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<"<<endl;
    cout<<"doctor name\t\tnational number\n";
    vector<doctor> tempDoctors = h->getDoctors();
    for(int i=0;i<tempDoctors.size();i++){
        cout<<tempDoctors[i].getName()<<"\t\t"<<tempDoctors[i].getNationalNum()<<endl;
    }
    cout<<"------------------------------------\n";
    cout<<"nurse name\t\tnationalnumber\n";
    vector<nurse> tempNurses = h->getNurses();
    cout<<(tempNurses.size());
    for(int j=0;j<tempNurses.size();j++){
        cout<<tempNurses[j].getName()<<"\t\t"<<tempNurses[j].getNationalNum()<<endl;
    }
}
#endif