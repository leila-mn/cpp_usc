#include "hospital.h"
#include <vector>
#include <iostream>

using namespace std;
int main(){
    hospital h1;
    h1.setName("Elm o farhang");
    doctor d1("dr.khalili");
    d1.setNationalNum(4572857319);
    doctor d2("dr.gilani");
    d2.setNationalNum(1234566782);
    h1.addDoctor(d1);
    h1.addDoctor(d2);
    nurse n1("mrs.mohammad nejad");
    n1.setNationalNum(9872648376);
    nurse n2("mr.tafazzol");
    n2.setNationalNum(6743728338);
    nurse n3("mr.sanati");
    n3.setNationalNum(9872648376);
    h1.addNurse(n1);
    h1.addNurse(n2);
    h1.addNurse(n3);
    printEmployees(&h1);
    return 0;
}
