#include <iostream>
#include <math.h>
using namespace std;

class Point{
public:
Point(int x,int y){
    this->x = x;
    this->y = y;
}
float getDistance(const Point& p){
    return sqrt(pow(p.x-this->x,2)+pow(p.y-this->y,2));
}
private:
    int x, y;
};
int main(){
    Point p(0,9);
    cout<<"distance is:\t"<<p.getDistance(Point(0,0))<<endl;
}