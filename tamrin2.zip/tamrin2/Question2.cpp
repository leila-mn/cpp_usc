#include <iostream>
using namespace std;

class Time{
public:
    Time(){
        this->hours=0;
        this->minutes=0;
        this->seconds=0;
    }
    Time(int h,int m,int s){
        this->hours=h;
        this->minutes=m;
        this->seconds=s;
    }
    void display(){
        cout<<this->hours<<':'<<this->minutes<<':'<<this->seconds<<endl;
    }
    int getHours(){return this->hours;}
    int getMins(){return this->minutes;}
    int getSec(){return this->seconds;}
    static Time addTime(const Time& t1,const Time& t2){
        int hoursSum = t1.hours + t2.hours;
        int minutSum = t1.minutes + t2.minutes;
        int secndSum = t1.seconds + t2.seconds;
        return(Time(hoursSum,minutSum,secndSum));
    }
private:
    int hours;
    int minutes;
    int seconds;
};
int main(){
    Time t1(11,32,23);
    Time t2(00,00,1);
    Time newTime = Time::addTime(t1,t2);
    newTime.display();
}