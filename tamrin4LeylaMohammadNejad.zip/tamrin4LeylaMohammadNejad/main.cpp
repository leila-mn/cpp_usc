#include "hospital.h"
#include <vector>
#include <iostream>
#include <chrono> 
#include <ctime> 
#include <fstream>
#include <stdlib.h>
#include <regex>
const std::regex comma(",");

int main()
{
    hospital h1;
    h1.setName("Elm o farhang");
    std::ifstream mesh("hospital_personnel_list - Sheet1.csv");
    std::vector<std::vector<std::string>> point_coordinates;
    std::string line{};
    while (mesh && getline(mesh, line)) {
        std::vector<std::string> row{ std::sregex_token_iterator(line.begin(),line.end(),comma,-1), std::sregex_token_iterator() };
        point_coordinates.push_back(row);
    }
    for(int i=0;i<point_coordinates.size();i++){
        doctor tmpDoctor(point_coordinates[i][0]);
        tmpDoctor.setNationalNum(std::stol(point_coordinates[i][1]));
        h1.addDoctor(tmpDoctor);
        nurse tmpNurse(point_coordinates[i][2]);
        tmpNurse.setNationalNum(std::stol(point_coordinates[i][3]));
        h1.addNurse(tmpNurse);
    }
    printEmployees(&h1);
    std::vector<doctor>h1doctors = h1.getDoctors();
    std::vector<nurse>h1nurses = h1.getNurses();
    int key=0;
    while(true){
        switch(key){
            case 0:
                break;
            case 1:
                {
                    for (int i=0;i<h1doctors.size();i++)
                        std::cout<<i<<"_"<<h1doctors[i].getName()<<std::endl;
                    break;
                }
            case 2:
                {
                    for (int i=0;i<h1nurses.size();i++)
                        std::cout<<i<<"_"<<h1nurses[i].getName()<<std::endl;
                    break;
                }
            case 3:
                {
                    auto timenow = chrono::system_clock::to_time_t(chrono::system_clock::now());
                    cout << ctime(&timenow) << endl; 
                    break;
                }
            case 4:
                return 0;
        }
        cout<<"press one of these keys to:\n1) show the list of doctors\n2) show the list of nurses\n3) see present time of the system\n4) EXIT\n";
        cin>>key;
        system("clear");
    }
    return 0;
}

// int main(){
    
//     doctor d1("dr.khalili");
//     d1.setNationalNum(4572857319);
//     doctor d2("dr.gilani");
//     d2.setNationalNum(1234566782);
//     h1.addDoctor(d1);
//     h1.addDoctor(d2);
//     nurse n1("mrs.mohammad nejad");
//     n1.setNationalNum(9872648376);
//     nurse n2("mr.tafazzol");
//     n2.setNationalNum(6743728338);
//     nurse n3("mr.sanati");
//     n3.setNationalNum(9872648376);
//     h1.addNurse(n1);
//     h1.addNurse(n2);
//     h1.addNurse(n3);
//     return 0;
// }
