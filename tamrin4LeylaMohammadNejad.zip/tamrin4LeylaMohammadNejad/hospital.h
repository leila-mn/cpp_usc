#ifndef HOSPITAL_H
#define HOSPITAL_H

#include "personnel.h"
#include <vector>
#include <iostream>

class hospital{
    std::string name;
    vector<doctor>doctors;
    vector<nurse>nurses;
public:
    hospital(){
        vector<doctor>doctors{};
        vector<nurse>nurses{};
        this->name="doesn't have a name yet!!!!!!\n";
    };
    std::string getName(){return this->name;};
    void setName(std::string inputName){this->name = inputName;}
    vector<doctor> getDoctors(){return this->doctors;};
    void addDoctor(doctor& d1){this->doctors.push_back(d1);};
    vector<nurse> getNurses(){return this->nurses;};
    void addNurse(nurse n1){this->nurses.push_back(n1);};

};
void printEmployees(hospital* h){
    cout<<"hospital name:\t\t"<<h->getName()<<endl;
    cout<<"<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<"<<endl;
    cout<<"doctor name\t\tnational number\n";
    vector<doctor> tempDoctors = h->getDoctors();
    for(int i=0;i<tempDoctors.size();i++){
        cout<<tempDoctors[i].getName()<<"\t\t"<<tempDoctors[i].getNationalNum()<<endl;
    }
    cout<<"------------------------------------\n";
    cout<<"nurse name\t\tnationalnumber\n";
    vector<nurse> tempNurses = h->getNurses();
    cout<<(tempNurses.size());
    for(int j=0;j<tempNurses.size();j++){
        cout<<tempNurses[j].getName()<<"\t\t"<<tempNurses[j].getNationalNum()<<endl;
    }
    cout<<"#######################################\n";
}
// #include <iostream>
// #include <fstream>
// // #include <string>
// // #include <vector>
// #include <iterator>
// #include <regex>


#endif